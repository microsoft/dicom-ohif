(globalThis["webpackChunk"] = globalThis["webpackChunk"] || []).push([[483],{

/***/ 79697:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  A: () => (/* binding */ drawingSvg_draw)
});

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/store/index.js + 4 modules
var store = __webpack_require__(61738);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var esm = __webpack_require__(92136);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/drawingSvg/getSvgDrawingHelper.js


const VIEWPORT_ELEMENT = 'viewport-element';
function getSvgDrawingHelper(element) {
    const enabledElement = (0,esm.getEnabledElement)(element);
    const { viewportId, renderingEngineId } = enabledElement;
    const canvasHash = `${viewportId}:${renderingEngineId}`;
    const svgLayerElement = _getSvgLayer(element);
    Object.keys(store/* state */.wk.svgNodeCache[canvasHash]).forEach((cacheKey) => {
        store/* state */.wk.svgNodeCache[canvasHash][cacheKey].touched = false;
    });
    return {
        svgLayerElement: svgLayerElement,
        svgNodeCacheForCanvas: store/* state */.wk.svgNodeCache,
        getSvgNode: getSvgNode.bind(this, canvasHash),
        appendNode: appendNode.bind(this, svgLayerElement, canvasHash),
        setNodeTouched: setNodeTouched.bind(this, canvasHash),
        clearUntouched: clearUntouched.bind(this, svgLayerElement, canvasHash),
    };
}
function _getSvgLayer(element) {
    const viewportElement = `.${VIEWPORT_ELEMENT}`;
    const internalDivElement = element.querySelector(viewportElement);
    const svgLayer = internalDivElement.querySelector(':scope > .svg-layer');
    return svgLayer;
}
function getSvgNode(canvasHash, cacheKey) {
    if (!store/* state */.wk.svgNodeCache[canvasHash]) {
        return;
    }
    if (store/* state */.wk.svgNodeCache[canvasHash][cacheKey]) {
        return store/* state */.wk.svgNodeCache[canvasHash][cacheKey].domRef;
    }
}
function appendNode(svgLayerElement, canvasHash, svgNode, cacheKey) {
    if (!store/* state */.wk.svgNodeCache[canvasHash]) {
        return null;
    }
    store/* state */.wk.svgNodeCache[canvasHash][cacheKey] = {
        touched: true,
        domRef: svgNode,
    };
    svgLayerElement.appendChild(svgNode);
}
function setNodeTouched(canvasHash, cacheKey) {
    if (!store/* state */.wk.svgNodeCache[canvasHash]) {
        return;
    }
    if (store/* state */.wk.svgNodeCache[canvasHash][cacheKey]) {
        store/* state */.wk.svgNodeCache[canvasHash][cacheKey].touched = true;
    }
}
function clearUntouched(svgLayerElement, canvasHash) {
    if (!store/* state */.wk.svgNodeCache[canvasHash]) {
        return;
    }
    Object.keys(store/* state */.wk.svgNodeCache[canvasHash]).forEach((cacheKey) => {
        const cacheEntry = store/* state */.wk.svgNodeCache[canvasHash][cacheKey];
        if (!cacheEntry.touched && cacheEntry.domRef) {
            svgLayerElement.removeChild(cacheEntry.domRef);
            delete store/* state */.wk.svgNodeCache[canvasHash][cacheKey];
        }
    });
}
/* harmony default export */ const drawingSvg_getSvgDrawingHelper = (getSvgDrawingHelper);

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/drawingSvg/draw.js

function draw(element, fn) {
    const svgDrawingHelper = drawingSvg_getSvgDrawingHelper(element);
    fn(svgDrawingHelper);
    svgDrawingHelper.clearUntouched();
}
/* harmony default export */ const drawingSvg_draw = (draw);


/***/ }),

/***/ 12468:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var ToolModes;
(function (ToolModes) {
    ToolModes["Active"] = "Active";
    ToolModes["Passive"] = "Passive";
    ToolModes["Enabled"] = "Enabled";
    ToolModes["Disabled"] = "Disabled";
})(ToolModes || (ToolModes = {}));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ToolModes);


/***/ }),

/***/ 27630:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  A: () => (/* binding */ ToolGroupManager_createToolGroup)
});

// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/store/index.js + 4 modules
var store = __webpack_require__(61738);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/enums/index.js + 3 modules
var enums = __webpack_require__(84901);
// EXTERNAL MODULE: ../../../node_modules/lodash.get/index.js
var lodash_get = __webpack_require__(51008);
var lodash_get_default = /*#__PURE__*/__webpack_require__.n(lodash_get);
// EXTERNAL MODULE: ../../../node_modules/lodash.clonedeep/index.js
var lodash_clonedeep = __webpack_require__(48463);
var lodash_clonedeep_default = /*#__PURE__*/__webpack_require__.n(lodash_clonedeep);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/core/dist/esm/index.js + 28 modules
var esm = __webpack_require__(92136);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/cursors/index.js + 5 modules
var cursors = __webpack_require__(32916);
// EXTERNAL MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/cursors/elementCursor.js
var elementCursor = __webpack_require__(40233);
;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/store/ToolGroupManager/ToolGroup.js








const { Active, Passive, Enabled, Disabled } = enums.ToolModes;
const PRIMARY_BINDINGS = [{ mouseButton: enums.MouseBindings.Primary }];
class ToolGroup {
    constructor(id) {
        this.viewportsInfo = [];
        this.toolOptions = {};
        this.currentActivePrimaryToolName = null;
        this.prevActivePrimaryToolName = null;
        this.restoreToolOptions = {};
        this._toolInstances = {};
        this.id = id;
    }
    getViewportIds() {
        return this.viewportsInfo.map(({ viewportId }) => viewportId);
    }
    getViewportsInfo() {
        return this.viewportsInfo.slice();
    }
    getToolInstance(toolInstanceName) {
        const toolInstance = this._toolInstances[toolInstanceName];
        if (!toolInstance) {
            console.warn(`'${toolInstanceName}' is not registered with this toolGroup (${this.id}).`);
            return;
        }
        return toolInstance;
    }
    getToolInstances() {
        return this._toolInstances;
    }
    hasTool(toolName) {
        return !!this._toolInstances[toolName];
    }
    addTool(toolName, configuration = {}) {
        const toolDefinition = store/* state */.wk.tools[toolName];
        const hasToolName = typeof toolName !== 'undefined' && toolName !== '';
        const localToolInstance = this.toolOptions[toolName];
        if (!hasToolName) {
            console.warn('Tool with configuration did not produce a toolName: ', configuration);
            return;
        }
        if (!toolDefinition) {
            console.warn(`'${toolName}' is not registered with the library. You need to use cornerstoneTools.addTool to register it.`);
            return;
        }
        if (localToolInstance) {
            console.warn(`'${toolName}' is already registered for ToolGroup ${this.id}.`);
            return;
        }
        const { toolClass: ToolClass } = toolDefinition;
        const toolProps = {
            name: toolName,
            toolGroupId: this.id,
            configuration,
        };
        const instantiatedTool = new ToolClass(toolProps);
        this._toolInstances[toolName] = instantiatedTool;
    }
    addToolInstance(toolName, parentClassName, configuration = {}) {
        let ToolClassToUse = store/* state */.wk.tools[toolName]
            ?.toolClass;
        if (!ToolClassToUse) {
            const ParentClass = store/* state */.wk.tools[parentClassName]
                .toolClass;
            class ToolInstance extends ParentClass {
            }
            ToolInstance.toolName = toolName;
            ToolClassToUse = ToolInstance;
            store/* state */.wk.tools[toolName] = {
                toolClass: ToolInstance,
            };
        }
        this.addTool(ToolClassToUse.toolName, configuration);
    }
    addViewport(viewportId, renderingEngineId) {
        if (typeof viewportId !== 'string') {
            throw new Error('viewportId must be defined and be a string');
        }
        const renderingEngines = (0,esm.getRenderingEngines)();
        if (!renderingEngineId && renderingEngines.length > 1) {
            throw new Error('You must specify a renderingEngineId when there are multiple rendering engines.');
        }
        const renderingEngineUIDToUse = renderingEngineId || renderingEngines[0].id;
        if (!this.viewportsInfo.some(({ viewportId: vpId }) => vpId === viewportId)) {
            this.viewportsInfo.push({
                viewportId,
                renderingEngineId: renderingEngineUIDToUse,
            });
        }
        const toolName = this.getActivePrimaryMouseButtonTool();
        const runtimeSettings = esm.Settings.getRuntimeSettings();
        if (runtimeSettings.get('useCursors')) {
            this.setViewportsCursorByToolName(toolName);
        }
        const eventDetail = {
            toolGroupId: this.id,
            viewportId,
            renderingEngineId: renderingEngineUIDToUse,
        };
        (0,esm.triggerEvent)(esm.eventTarget, enums.Events.TOOLGROUP_VIEWPORT_ADDED, eventDetail);
    }
    removeViewports(renderingEngineId, viewportId) {
        const indices = [];
        this.viewportsInfo.forEach((vpInfo, index) => {
            let match = false;
            if (vpInfo.renderingEngineId === renderingEngineId) {
                match = true;
                if (viewportId && vpInfo.viewportId !== viewportId) {
                    match = false;
                }
            }
            if (match) {
                indices.push(index);
            }
        });
        if (indices.length) {
            for (let i = indices.length - 1; i >= 0; i--) {
                this.viewportsInfo.splice(indices[i], 1);
            }
        }
        const eventDetail = {
            toolGroupId: this.id,
            viewportId,
            renderingEngineId,
        };
        (0,esm.triggerEvent)(esm.eventTarget, enums.Events.TOOLGROUP_VIEWPORT_REMOVED, eventDetail);
    }
    setActiveStrategy(toolName, strategyName) {
        const toolInstance = this._toolInstances[toolName];
        if (toolInstance === undefined) {
            console.warn(`Tool ${toolName} not added to toolGroup, can't set tool configuration.`);
            return;
        }
        toolInstance.setActiveStrategy(strategyName);
    }
    setToolMode(toolName, mode, options = {}) {
        if (!toolName) {
            console.warn('setToolMode: toolName must be defined');
            return;
        }
        if (mode === enums.ToolModes.Active) {
            this.setToolActive(toolName, options || this.restoreToolOptions[toolName]);
            return;
        }
        if (mode === enums.ToolModes.Passive) {
            this.setToolPassive(toolName);
            return;
        }
        if (mode === enums.ToolModes.Enabled) {
            this.setToolEnabled(toolName);
            return;
        }
        if (mode === enums.ToolModes.Disabled) {
            this.setToolDisabled(toolName);
            return;
        }
        console.warn('setToolMode: mode must be defined');
    }
    setToolActive(toolName, toolBindingsOptions = {}) {
        const toolInstance = this._toolInstances[toolName];
        if (toolInstance === undefined) {
            console.warn(`Tool ${toolName} not added to toolGroup, can't set tool mode.`);
            return;
        }
        if (!toolInstance) {
            console.warn(`'${toolName}' instance ${toolInstance} is not registered with this toolGroup, can't set tool mode.`);
            return;
        }
        const prevBindings = this.toolOptions[toolName]
            ? this.toolOptions[toolName].bindings
            : [];
        const newBindings = toolBindingsOptions.bindings
            ? toolBindingsOptions.bindings
            : [];
        const bindingsToUse = [...prevBindings, ...newBindings].reduce((unique, binding) => {
            const TouchBinding = binding.numTouchPoints !== undefined;
            const MouseBinding = binding.mouseButton !== undefined;
            if (!unique.some((obj) => hasSameBinding(obj, binding)) &&
                (TouchBinding || MouseBinding)) {
                unique.push(binding);
            }
            return unique;
        }, []);
        const toolOptions = {
            bindings: bindingsToUse,
            mode: Active,
        };
        this.toolOptions[toolName] = toolOptions;
        this._toolInstances[toolName].mode = Active;
        const runtimeSettings = esm.Settings.getRuntimeSettings();
        const useCursor = runtimeSettings.get('useCursors');
        if (this._hasMousePrimaryButtonBinding(toolBindingsOptions) && useCursor) {
            this.setViewportsCursorByToolName(toolName);
        }
        else {
            const activeToolIdentifier = this.getActivePrimaryMouseButtonTool();
            if (!activeToolIdentifier && useCursor) {
                const cursor = cursors.MouseCursor.getDefinedCursor('default');
                this._setCursorForViewports(cursor);
            }
        }
        if (this._hasMousePrimaryButtonBinding(toolBindingsOptions)) {
            if (this.prevActivePrimaryToolName === null) {
                this.prevActivePrimaryToolName = toolName;
            }
            else {
                this.prevActivePrimaryToolName = this.currentActivePrimaryToolName;
            }
            this.currentActivePrimaryToolName = toolName;
        }
        if (typeof toolInstance.onSetToolActive === 'function') {
            toolInstance.onSetToolActive();
        }
        this._renderViewports();
        const eventDetail = {
            toolGroupId: this.id,
            toolName,
            toolBindingsOptions,
        };
        (0,esm.triggerEvent)(esm.eventTarget, enums.Events.TOOL_ACTIVATED, eventDetail);
        this._triggerToolModeChangedEvent(toolName, Active, toolBindingsOptions);
    }
    setToolPassive(toolName, options) {
        const toolInstance = this._toolInstances[toolName];
        if (toolInstance === undefined) {
            console.warn(`Tool ${toolName} not added to toolGroup, can't set tool mode.`);
            return;
        }
        const prevToolOptions = this.getToolOptions(toolName);
        const toolOptions = Object.assign({
            bindings: prevToolOptions ? prevToolOptions.bindings : [],
        }, prevToolOptions, {
            mode: Passive,
        });
        const matchBindings = Array.isArray(options?.removeAllBindings)
            ? options.removeAllBindings
            : this.getDefaultPrimaryBindings();
        toolOptions.bindings = toolOptions.bindings.filter((binding) => options?.removeAllBindings !== true &&
            !matchBindings.some((matchBinding) => hasSameBinding(binding, matchBinding)));
        let mode = Passive;
        if (toolOptions.bindings.length !== 0) {
            mode = Active;
            toolOptions.mode = mode;
        }
        this.toolOptions[toolName] = toolOptions;
        toolInstance.mode = mode;
        if (typeof toolInstance.onSetToolPassive === 'function') {
            toolInstance.onSetToolPassive();
        }
        this._renderViewports();
        this._triggerToolModeChangedEvent(toolName, Passive);
    }
    setToolEnabled(toolName) {
        const toolInstance = this._toolInstances[toolName];
        if (toolInstance === undefined) {
            console.warn(`Tool ${toolName} not added to toolGroup, can't set tool mode.`);
            return;
        }
        const toolOptions = {
            bindings: [],
            mode: Enabled,
        };
        this.toolOptions[toolName] = toolOptions;
        toolInstance.mode = Enabled;
        if (typeof toolInstance.onSetToolEnabled === 'function') {
            toolInstance.onSetToolEnabled();
        }
        this._renderViewports();
        this._triggerToolModeChangedEvent(toolName, Enabled);
    }
    setToolDisabled(toolName) {
        const toolInstance = this._toolInstances[toolName];
        if (toolInstance === undefined) {
            console.warn(`Tool ${toolName} not added to toolGroup, can't set tool mode.`);
            return;
        }
        const toolOptions = {
            bindings: [],
            mode: Disabled,
        };
        this.restoreToolOptions[toolName] = this.toolOptions[toolName];
        this.toolOptions[toolName] = toolOptions;
        toolInstance.mode = Disabled;
        if (typeof toolInstance.onSetToolDisabled === 'function') {
            toolInstance.onSetToolDisabled();
        }
        this._renderViewports();
        this._triggerToolModeChangedEvent(toolName, Disabled);
    }
    getToolOptions(toolName) {
        const toolOptionsForTool = this.toolOptions[toolName];
        if (toolOptionsForTool === undefined) {
            return;
        }
        return toolOptionsForTool;
    }
    getActivePrimaryMouseButtonTool() {
        return Object.keys(this.toolOptions).find((toolName) => {
            const toolOptions = this.toolOptions[toolName];
            return (toolOptions.mode === Active &&
                this._hasMousePrimaryButtonBinding(toolOptions));
        });
    }
    setViewportsCursorByToolName(toolName, strategyName) {
        const cursor = this._getCursor(toolName, strategyName);
        this._setCursorForViewports(cursor);
    }
    _getCursor(toolName, strategyName) {
        let cursorName;
        let cursor;
        if (strategyName) {
            cursorName = `${toolName}.${strategyName}`;
            cursor = cursors.SVGMouseCursor.getDefinedCursor(cursorName, true);
            if (cursor) {
                return cursor;
            }
        }
        cursorName = `${toolName}`;
        cursor = cursors.SVGMouseCursor.getDefinedCursor(cursorName, true);
        if (cursor) {
            return cursor;
        }
        cursorName = toolName;
        cursor = cursors.SVGMouseCursor.getDefinedCursor(cursorName, true);
        if (cursor) {
            return cursor;
        }
        return cursors.MouseCursor.getDefinedCursor('default');
    }
    _setCursorForViewports(cursor) {
        this.viewportsInfo.forEach(({ renderingEngineId, viewportId }) => {
            const enabledElement = (0,esm.getEnabledElementByIds)(viewportId, renderingEngineId);
            if (!enabledElement) {
                return;
            }
            const { viewport } = enabledElement;
            (0,elementCursor.initElementCursor)(viewport.element, cursor);
        });
    }
    setToolConfiguration(toolName, configuration, overwrite) {
        const toolInstance = this._toolInstances[toolName];
        if (toolInstance === undefined) {
            console.warn(`Tool ${toolName} not present, can't set tool configuration.`);
            return false;
        }
        let _configuration;
        if (overwrite) {
            _configuration = configuration;
        }
        else {
            _configuration = Object.assign(toolInstance.configuration, configuration);
        }
        toolInstance.configuration = _configuration;
        if (typeof toolInstance.onSetToolConfiguration === 'function') {
            toolInstance.onSetToolConfiguration();
        }
        this._renderViewports();
        return true;
    }
    getDefaultMousePrimary() {
        return enums.MouseBindings.Primary;
    }
    getDefaultPrimaryBindings() {
        return PRIMARY_BINDINGS;
    }
    getToolConfiguration(toolName, configurationPath) {
        if (this._toolInstances[toolName] === undefined) {
            console.warn(`Tool ${toolName} not present, can't set tool configuration.`);
            return;
        }
        const _configuration = lodash_get_default()(this._toolInstances[toolName].configuration, configurationPath) ||
            this._toolInstances[toolName].configuration;
        return lodash_clonedeep_default()(_configuration);
    }
    getPrevActivePrimaryToolName() {
        return this.prevActivePrimaryToolName;
    }
    clone(newToolGroupId, fnToolFilter = null) {
        let toolGroup = store/* ToolGroupManager.getToolGroup */.dU.getToolGroup(newToolGroupId);
        if (toolGroup) {
            console.warn(`ToolGroup ${newToolGroupId} already exists`);
            return toolGroup;
        }
        toolGroup = store/* ToolGroupManager.createToolGroup */.dU.createToolGroup(newToolGroupId);
        fnToolFilter = fnToolFilter ?? (() => true);
        Object.keys(this._toolInstances)
            .filter(fnToolFilter)
            .forEach((toolName) => {
            const sourceToolInstance = this._toolInstances[toolName];
            const sourceToolOptions = this.toolOptions[toolName];
            const sourceToolMode = sourceToolInstance.mode;
            toolGroup.addTool(toolName);
            toolGroup.setToolMode(toolName, sourceToolMode, {
                bindings: sourceToolOptions.bindings ?? [],
            });
        });
        return toolGroup;
    }
    _hasMousePrimaryButtonBinding(toolOptions) {
        const primaryBindings = this.getDefaultPrimaryBindings();
        return toolOptions?.bindings?.some((binding) => primaryBindings.some((primary) => hasSameBinding(binding, primary)));
    }
    _renderViewports() {
        this.viewportsInfo.forEach(({ renderingEngineId, viewportId }) => {
            (0,esm.getRenderingEngine)(renderingEngineId).renderViewport(viewportId);
        });
    }
    _triggerToolModeChangedEvent(toolName, mode, toolBindingsOptions) {
        const eventDetail = {
            toolGroupId: this.id,
            toolName,
            mode,
            toolBindingsOptions,
        };
        (0,esm.triggerEvent)(esm.eventTarget, enums.Events.TOOL_MODE_CHANGED, eventDetail);
    }
}
function hasSameBinding(binding1, binding2) {
    if (binding1.mouseButton !== binding2.mouseButton) {
        return false;
    }
    if (binding1.numTouchPoints !== binding2.numTouchPoints) {
        return false;
    }
    return binding1.modifierKey === binding2.modifierKey;
}

;// CONCATENATED MODULE: ../../../node_modules/@cornerstonejs/tools/dist/esm/store/ToolGroupManager/createToolGroup.js


function createToolGroup(toolGroupId) {
    const toolGroupWithIdExists = store/* state */.wk.toolGroups.some((tg) => tg.id === toolGroupId);
    if (toolGroupWithIdExists) {
        console.warn(`'${toolGroupId}' already exists.`);
        return;
    }
    const toolGroup = new ToolGroup(toolGroupId);
    store/* state */.wk.toolGroups.push(toolGroup);
    return toolGroup;
}
/* harmony default export */ const ToolGroupManager_createToolGroup = (createToolGroup);


/***/ }),

/***/ 648:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61738);
/* harmony import */ var _destroyToolGroup__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59755);


function destroy() {
    const toolGroups = [..._index__WEBPACK_IMPORTED_MODULE_0__/* .state */ .wk.toolGroups];
    for (const toolGroup of toolGroups) {
        (0,_destroyToolGroup__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A)(toolGroup.id);
    }
    _index__WEBPACK_IMPORTED_MODULE_0__/* .state */ .wk.toolGroups = [];
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (destroy);


/***/ }),

/***/ 59755:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61738);
/* harmony import */ var _stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(63421);
/* harmony import */ var _utilities_segmentation_triggerSegmentationRender__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(49521);



function destroyToolGroup(toolGroupId) {
    const toolGroupIndex = _index__WEBPACK_IMPORTED_MODULE_0__/* .state */ .wk.toolGroups.findIndex((tg) => tg.id === toolGroupId);
    if (toolGroupIndex > -1) {
        _utilities_segmentation_triggerSegmentationRender__WEBPACK_IMPORTED_MODULE_2__/* .segmentationRenderingEngine */ .px.removeToolGroup(toolGroupId);
        (0,_stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_1__.removeSegmentationsFromToolGroup)(toolGroupId);
        _index__WEBPACK_IMPORTED_MODULE_0__/* .state */ .wk.toolGroups.splice(toolGroupIndex, 1);
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (destroyToolGroup);


/***/ }),

/***/ 3193:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61738);

function getAllToolGroups() {
    return _index__WEBPACK_IMPORTED_MODULE_0__/* .state */ .wk.toolGroups;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getAllToolGroups);


/***/ }),

/***/ 29697:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61738);

function getToolGroup(toolGroupId) {
    return _index__WEBPACK_IMPORTED_MODULE_0__/* .state */ .wk.toolGroups.find((s) => s.id === toolGroupId);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getToolGroup);


/***/ }),

/***/ 64109:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61738);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(84901);


const MODES = [_enums__WEBPACK_IMPORTED_MODULE_1__.ToolModes.Active, _enums__WEBPACK_IMPORTED_MODULE_1__.ToolModes.Passive, _enums__WEBPACK_IMPORTED_MODULE_1__.ToolModes.Enabled];
function getToolGroupsWithToolName(toolName) {
    return _index__WEBPACK_IMPORTED_MODULE_0__/* .state */ .wk.toolGroups.filter(({ toolOptions }) => {
        const toolGroupToolNames = Object.keys(toolOptions);
        for (let i = 0; i < toolGroupToolNames.length; i++) {
            if (toolName !== toolGroupToolNames[i]) {
                continue;
            }
            if (!toolOptions[toolName]) {
                continue;
            }
            if (MODES.includes(toolOptions[toolName].mode)) {
                return true;
            }
        }
        return false;
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getToolGroupsWithToolName);


/***/ }),

/***/ 39244:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var gl_matrix__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(44753);
/* harmony import */ var _utilities_getCalibratedUnits__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(24592);
/* harmony import */ var _utilities__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(74119);
/* harmony import */ var _utilities_math__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(73047);
/* harmony import */ var _utilities_planar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(84797);
/* harmony import */ var _utilities_throttle__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(21090);
/* harmony import */ var _utilities_viewportFilters__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(90252);
/* harmony import */ var _utilities_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(23072);
/* harmony import */ var _planarFreehandROITool_drawLoop__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(14695);
/* harmony import */ var _planarFreehandROITool_editLoopCommon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1344);
/* harmony import */ var _planarFreehandROITool_closedContourEditLoop__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(30911);
/* harmony import */ var _planarFreehandROITool_openContourEditLoop__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(90511);
/* harmony import */ var _planarFreehandROITool_openContourEndEditLoop__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(72702);
/* harmony import */ var _planarFreehandROITool_renderMethods__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(11585);
/* harmony import */ var _stateManagement_annotation_helpers_state__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(54177);
/* harmony import */ var _drawingSvg__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(49574);
/* harmony import */ var _utilities_drawing__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(10910);
/* harmony import */ var _utilities_math_polyline__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(56634);
/* harmony import */ var _utilities_pointInShapeCallback__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(75403);
/* harmony import */ var _utilities_viewport_isViewportPreScaled__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(97022);
/* harmony import */ var _utilities_getModalityUnit__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(73801);
/* harmony import */ var _utilities_math_basic__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(83112);
/* harmony import */ var _utilities_contours_calculatePerimeter__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(53891);
/* harmony import */ var _base_ContourSegmentationBaseTool__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(76840);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(84901);


























const { pointCanProjectOnLine } = _utilities_math__WEBPACK_IMPORTED_MODULE_4__.polyline;
const { EPSILON } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.CONSTANTS;
const PARALLEL_THRESHOLD = 1 - EPSILON;
class PlanarFreehandROITool extends _base_ContourSegmentationBaseTool__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .A {
    constructor(toolProps = {}, defaultToolProps = {
        supportedInteractionTypes: ['Mouse', 'Touch'],
        configuration: {
            shadow: true,
            preventHandleOutsideImage: false,
            contourHoleAdditionModifierKey: _enums__WEBPACK_IMPORTED_MODULE_25__.KeyboardBindings.Shift,
            alwaysRenderOpenContourHandles: {
                enabled: false,
                radius: 2,
            },
            allowOpenContours: true,
            closeContourProximity: 10,
            checkCanvasEditFallbackProximity: 6,
            makeClockWise: true,
            subPixelResolution: 4,
            smoothing: {
                smoothOnAdd: false,
                smoothOnEdit: false,
                knotsRatioPercentageOnAdd: 40,
                knotsRatioPercentageOnEdit: 40,
            },
            interpolation: {
                enabled: false,
                onInterpolationComplete: null,
            },
            decimate: {
                enabled: false,
                epsilon: 0.1,
            },
            displayOnePointAsCrosshairs: false,
            calculateStats: true,
            getTextLines: defaultGetTextLines,
            statsCalculator: _utilities_math_basic__WEBPACK_IMPORTED_MODULE_22__.BasicStatsCalculator,
        },
    }) {
        super(toolProps, defaultToolProps);
        this.isDrawing = false;
        this.isEditingClosed = false;
        this.isEditingOpen = false;
        this.addNewAnnotation = (evt) => {
            const eventDetail = evt.detail;
            const { element } = eventDetail;
            const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getEnabledElement)(element);
            const { renderingEngine } = enabledElement;
            const annotation = this.createAnnotation(evt);
            this.addAnnotation(annotation, element);
            const viewportIdsToRender = (0,_utilities_viewportFilters__WEBPACK_IMPORTED_MODULE_7__.getViewportIdsWithToolToRender)(element, this.getToolName());
            this.activateDraw(evt, annotation, viewportIdsToRender);
            evt.preventDefault();
            (0,_utilities_triggerAnnotationRenderForViewportIds__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .A)(renderingEngine, viewportIdsToRender);
            return annotation;
        };
        this.handleSelectedCallback = (evt, annotation, handle) => {
            const eventDetail = evt.detail;
            const { element } = eventDetail;
            const viewportIdsToRender = (0,_utilities_viewportFilters__WEBPACK_IMPORTED_MODULE_7__.getViewportIdsWithToolToRender)(element, this.getToolName());
            this.activateOpenContourEndEdit(evt, annotation, viewportIdsToRender, handle);
        };
        this.toolSelectedCallback = (evt, annotation) => {
            const eventDetail = evt.detail;
            const { element } = eventDetail;
            const viewportIdsToRender = (0,_utilities_viewportFilters__WEBPACK_IMPORTED_MODULE_7__.getViewportIdsWithToolToRender)(element, this.getToolName());
            if (annotation.data.contour.closed) {
                this.activateClosedContourEdit(evt, annotation, viewportIdsToRender);
            }
            else {
                this.activateOpenContourEdit(evt, annotation, viewportIdsToRender);
            }
            evt.preventDefault();
        };
        this.isPointNearTool = (element, annotation, canvasCoords, proximity) => {
            const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getEnabledElement)(element);
            const { viewport } = enabledElement;
            const { polyline: points } = annotation.data.contour;
            let previousPoint = viewport.worldToCanvas(points[0]);
            for (let i = 1; i < points.length; i++) {
                const p1 = previousPoint;
                const p2 = viewport.worldToCanvas(points[i]);
                const canProject = pointCanProjectOnLine(canvasCoords, p1, p2, proximity);
                if (canProject) {
                    return true;
                }
                previousPoint = p2;
            }
            if (!annotation.data.contour.closed) {
                return false;
            }
            const pStart = viewport.worldToCanvas(points[0]);
            const pEnd = viewport.worldToCanvas(points[points.length - 1]);
            return pointCanProjectOnLine(canvasCoords, pStart, pEnd, proximity);
        };
        this.cancel = (element) => {
            const isDrawing = this.isDrawing;
            const isEditingOpen = this.isEditingOpen;
            const isEditingClosed = this.isEditingClosed;
            if (isDrawing) {
                this.cancelDrawing(element);
            }
            else if (isEditingOpen) {
                this.cancelOpenContourEdit(element);
            }
            else if (isEditingClosed) {
                this.cancelClosedContourEdit(element);
            }
        };
        this._calculateCachedStats = (annotation, viewport, renderingEngine, enabledElement) => {
            const { data } = annotation;
            const { cachedStats } = data;
            const { polyline: points, closed } = data.contour;
            const targetIds = Object.keys(cachedStats);
            for (let i = 0; i < targetIds.length; i++) {
                const targetId = targetIds[i];
                const image = this.getTargetIdImage(targetId, renderingEngine);
                if (!image) {
                    continue;
                }
                const { imageData, metadata } = image;
                const canvasCoordinates = points.map((p) => viewport.worldToCanvas(p));
                const canvasPoint = canvasCoordinates[0];
                const originalWorldPoint = viewport.canvasToWorld(canvasPoint);
                const deltaXPoint = viewport.canvasToWorld([
                    canvasPoint[0] + 1,
                    canvasPoint[1],
                ]);
                const deltaYPoint = viewport.canvasToWorld([
                    canvasPoint[0],
                    canvasPoint[1] + 1,
                ]);
                const deltaInX = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.distance */ .eR.distance(originalWorldPoint, deltaXPoint);
                const deltaInY = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.distance */ .eR.distance(originalWorldPoint, deltaYPoint);
                const worldPosIndex = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.transformWorldToIndex(imageData, points[0]);
                worldPosIndex[0] = Math.floor(worldPosIndex[0]);
                worldPosIndex[1] = Math.floor(worldPosIndex[1]);
                worldPosIndex[2] = Math.floor(worldPosIndex[2]);
                let iMin = worldPosIndex[0];
                let iMax = worldPosIndex[0];
                let jMin = worldPosIndex[1];
                let jMax = worldPosIndex[1];
                let kMin = worldPosIndex[2];
                let kMax = worldPosIndex[2];
                for (let j = 1; j < points.length; j++) {
                    const worldPosIndex = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.transformWorldToIndex(imageData, points[j]);
                    worldPosIndex[0] = Math.floor(worldPosIndex[0]);
                    worldPosIndex[1] = Math.floor(worldPosIndex[1]);
                    worldPosIndex[2] = Math.floor(worldPosIndex[2]);
                    iMin = Math.min(iMin, worldPosIndex[0]);
                    iMax = Math.max(iMax, worldPosIndex[0]);
                    jMin = Math.min(jMin, worldPosIndex[1]);
                    jMax = Math.max(jMax, worldPosIndex[1]);
                    kMin = Math.min(kMin, worldPosIndex[2]);
                    kMax = Math.max(kMax, worldPosIndex[2]);
                }
                const worldPosIndex2 = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.transformWorldToIndex(imageData, points[1]);
                worldPosIndex2[0] = Math.floor(worldPosIndex2[0]);
                worldPosIndex2[1] = Math.floor(worldPosIndex2[1]);
                worldPosIndex2[2] = Math.floor(worldPosIndex2[2]);
                const { scale, areaUnits } = (0,_utilities_getCalibratedUnits__WEBPACK_IMPORTED_MODULE_2__/* .getCalibratedLengthUnitsAndScale */ .Op)(image, () => {
                    const polyline = data.contour.polyline;
                    const numPoints = polyline.length;
                    const projectedPolyline = new Array(numPoints);
                    for (let i = 0; i < numPoints; i++) {
                        projectedPolyline[i] = viewport.worldToCanvas(polyline[i]);
                    }
                    const { maxX: canvasMaxX, maxY: canvasMaxY, minX: canvasMinX, minY: canvasMinY, } = _utilities__WEBPACK_IMPORTED_MODULE_3__.math.polyline.getAABB(projectedPolyline);
                    const topLeftBBWorld = viewport.canvasToWorld([
                        canvasMinX,
                        canvasMinY,
                    ]);
                    const topLeftBBIndex = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.transformWorldToIndex(imageData, topLeftBBWorld);
                    const bottomRightBBWorld = viewport.canvasToWorld([
                        canvasMaxX,
                        canvasMaxY,
                    ]);
                    const bottomRightBBIndex = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.transformWorldToIndex(imageData, bottomRightBBWorld);
                    return [topLeftBBIndex, bottomRightBBIndex];
                });
                let area = _utilities_math__WEBPACK_IMPORTED_MODULE_4__.polyline.getArea(canvasCoordinates) / scale / scale;
                area *= deltaInX * deltaInY;
                const iDelta = 0.01 * (iMax - iMin);
                const jDelta = 0.01 * (jMax - jMin);
                const kDelta = 0.01 * (kMax - kMin);
                iMin = Math.floor(iMin - iDelta);
                iMax = Math.ceil(iMax + iDelta);
                jMin = Math.floor(jMin - jDelta);
                jMax = Math.ceil(jMax + jDelta);
                kMin = Math.floor(kMin - kDelta);
                kMax = Math.ceil(kMax + kDelta);
                const boundsIJK = [
                    [iMin, iMax],
                    [jMin, jMax],
                    [kMin, kMax],
                ];
                const worldPosEnd = imageData.indexToWorld([iMax, jMax, kMax]);
                const canvasPosEnd = viewport.worldToCanvas(worldPosEnd);
                let curRow = 0;
                let intersections = [];
                let intersectionCounter = 0;
                const pointsInShape = (0,_utilities_pointInShapeCallback__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .A)(imageData, (pointLPS, pointIJK) => {
                    let result = true;
                    const point = viewport.worldToCanvas(pointLPS);
                    if (point[1] != curRow) {
                        intersectionCounter = 0;
                        curRow = point[1];
                        intersections = (0,_utilities_math_polyline__WEBPACK_IMPORTED_MODULE_18__.getLineSegmentIntersectionsCoordinates)(canvasCoordinates, point, [canvasPosEnd[0], point[1]]);
                        intersections.sort((function (index) {
                            return function (a, b) {
                                return a[index] === b[index]
                                    ? 0
                                    : a[index] < b[index]
                                        ? -1
                                        : 1;
                            };
                        })(0));
                    }
                    if (intersections.length && point[0] > intersections[0][0]) {
                        intersections.shift();
                        intersectionCounter++;
                    }
                    if (intersectionCounter % 2 === 0) {
                        result = false;
                    }
                    return result;
                }, this.configuration.statsCalculator.statsCallback, boundsIJK);
                const modalityUnitOptions = {
                    isPreScaled: (0,_utilities_viewport_isViewportPreScaled__WEBPACK_IMPORTED_MODULE_20__/* .isViewportPreScaled */ .u)(viewport, targetId),
                    isSuvScaled: this.isSuvScaled(viewport, targetId, annotation.metadata.referencedImageId),
                };
                const modalityUnit = (0,_utilities_getModalityUnit__WEBPACK_IMPORTED_MODULE_21__/* .getModalityUnit */ .c)(metadata.Modality, annotation.metadata.referencedImageId, modalityUnitOptions);
                const stats = this.configuration.statsCalculator.getStatistics();
                cachedStats[targetId] = {
                    Modality: metadata.Modality,
                    area,
                    perimeter: (0,_utilities_contours_calculatePerimeter__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .A)(canvasCoordinates, closed),
                    mean: stats.mean?.value,
                    max: stats.max?.value,
                    stdDev: stats.stdDev?.value,
                    statsArray: stats.array,
                    pointsInShape: pointsInShape,
                    areaUnit: areaUnits,
                    modalityUnit,
                };
            }
            (0,_stateManagement_annotation_helpers_state__WEBPACK_IMPORTED_MODULE_15__/* .triggerAnnotationModified */ .XF)(annotation, enabledElement.viewport.element, _enums__WEBPACK_IMPORTED_MODULE_25__.ChangeTypes.StatsUpdated);
            annotation.invalidated = false;
            return cachedStats;
        };
        this._renderStats = (annotation, viewport, enabledElement, svgDrawingHelper) => {
            const { data } = annotation;
            const targetId = this.getTargetId(viewport);
            const styleSpecifier = {
                toolGroupId: this.toolGroupId,
                toolName: this.getToolName(),
                viewportId: enabledElement.viewport.id,
            };
            const options = this.getLinkedTextBoxStyle(styleSpecifier, annotation);
            if (!options.visibility) {
                return;
            }
            const textLines = this.configuration.getTextLines(data, targetId);
            if (!textLines || textLines.length === 0) {
                return;
            }
            const canvasCoordinates = data.contour.polyline.map((p) => viewport.worldToCanvas(p));
            if (!data.handles.textBox.hasMoved) {
                const canvasTextBoxCoords = (0,_utilities_drawing__WEBPACK_IMPORTED_MODULE_17__.getTextBoxCoordsCanvas)(canvasCoordinates);
                data.handles.textBox.worldPosition =
                    viewport.canvasToWorld(canvasTextBoxCoords);
            }
            const textBoxPosition = viewport.worldToCanvas(data.handles.textBox.worldPosition);
            const textBoxUID = '1';
            const boundingBox = (0,_drawingSvg__WEBPACK_IMPORTED_MODULE_16__.drawLinkedTextBox)(svgDrawingHelper, annotation.annotationUID ?? '', textBoxUID, textLines, textBoxPosition, canvasCoordinates, {}, options);
            const { x: left, y: top, width, height } = boundingBox;
            data.handles.textBox.worldBoundingBox = {
                topLeft: viewport.canvasToWorld([left, top]),
                topRight: viewport.canvasToWorld([left + width, top]),
                bottomLeft: viewport.canvasToWorld([left, top + height]),
                bottomRight: viewport.canvasToWorld([left + width, top + height]),
            };
        };
        (0,_planarFreehandROITool_drawLoop__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .A)(this);
        (0,_planarFreehandROITool_editLoopCommon__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .A)(this);
        (0,_planarFreehandROITool_closedContourEditLoop__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .A)(this);
        (0,_planarFreehandROITool_openContourEditLoop__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .A)(this);
        (0,_planarFreehandROITool_openContourEndEditLoop__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .A)(this);
        (0,_planarFreehandROITool_renderMethods__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .A)(this);
        this._throttledCalculateCachedStats = (0,_utilities_throttle__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .A)(this._calculateCachedStats, 100, { trailing: true });
    }
    filterInteractableAnnotationsForElement(element, annotations) {
        if (!annotations || !annotations.length) {
            return;
        }
        const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getEnabledElement)(element);
        const { viewport } = enabledElement;
        let annotationsToDisplay;
        if (viewport instanceof _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.VolumeViewport) {
            const camera = viewport.getCamera();
            const { spacingInNormalDirection } = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.getTargetVolumeAndSpacingInNormalDir(viewport, camera);
            annotationsToDisplay = this.filterAnnotationsWithinSlice(annotations, camera, spacingInNormalDirection);
        }
        else {
            annotationsToDisplay = (0,_utilities_planar__WEBPACK_IMPORTED_MODULE_5__.filterAnnotationsForDisplay)(viewport, annotations);
        }
        return annotationsToDisplay;
    }
    filterAnnotationsWithinSlice(annotations, camera, spacingInNormalDirection) {
        const { viewPlaneNormal } = camera;
        const annotationsWithParallelNormals = annotations.filter((td) => {
            const annotationViewPlaneNormal = td.metadata.viewPlaneNormal;
            const isParallel = Math.abs(gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.dot */ .eR.dot(viewPlaneNormal, annotationViewPlaneNormal)) >
                PARALLEL_THRESHOLD;
            return annotationViewPlaneNormal && isParallel;
        });
        if (!annotationsWithParallelNormals.length) {
            return [];
        }
        const halfSpacingInNormalDirection = spacingInNormalDirection / 2;
        const { focalPoint } = camera;
        const annotationsWithinSlice = [];
        for (const annotation of annotationsWithParallelNormals) {
            const data = annotation.data;
            const point = data.contour.polyline[0];
            if (!annotation.isVisible) {
                continue;
            }
            const dir = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.create */ .eR.create();
            gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.sub */ .eR.sub(dir, focalPoint, point);
            const dot = gl_matrix__WEBPACK_IMPORTED_MODULE_1__/* .vec3.dot */ .eR.dot(dir, viewPlaneNormal);
            if (Math.abs(dot) < halfSpacingInNormalDirection) {
                annotationsWithinSlice.push(annotation);
            }
        }
        return annotationsWithinSlice;
    }
    isContourSegmentationTool() {
        return false;
    }
    createAnnotation(evt) {
        const worldPos = evt.detail.currentPoints.world;
        const contourAnnotation = super.createAnnotation(evt);
        const onInterpolationComplete = (annotation) => {
            annotation.data.handles.points.length = 0;
        };
        const annotation = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.deepMerge(contourAnnotation, {
            data: {
                contour: {
                    polyline: [[...worldPos]],
                },
                label: '',
                cachedStats: {},
            },
            onInterpolationComplete,
        });
        return annotation;
    }
    getAnnotationStyle(context) {
        return super.getAnnotationStyle(context);
    }
    renderAnnotationInstance(renderContext) {
        const { enabledElement, targetId, svgDrawingHelper } = renderContext;
        const annotation = renderContext.annotation;
        let renderStatus = false;
        const { viewport, renderingEngine } = enabledElement;
        const isDrawing = this.isDrawing;
        const isEditingOpen = this.isEditingOpen;
        const isEditingClosed = this.isEditingClosed;
        if (!(isDrawing || isEditingOpen || isEditingClosed)) {
            if (this.configuration.displayOnePointAsCrosshairs &&
                annotation.data.contour.polyline.length === 1) {
                this.renderPointContourWithMarker(enabledElement, svgDrawingHelper, annotation);
            }
            else {
                this.renderContour(enabledElement, svgDrawingHelper, annotation);
            }
        }
        else {
            const activeAnnotationUID = this.commonData.annotation.annotationUID;
            if (annotation.annotationUID === activeAnnotationUID) {
                if (isDrawing) {
                    this.renderContourBeingDrawn(enabledElement, svgDrawingHelper, annotation);
                }
                else if (isEditingClosed) {
                    this.renderClosedContourBeingEdited(enabledElement, svgDrawingHelper, annotation);
                }
                else if (isEditingOpen) {
                    this.renderOpenContourBeingEdited(enabledElement, svgDrawingHelper, annotation);
                }
                else {
                    throw new Error(`Unknown ${this.getToolName()} annotation rendering state`);
                }
            }
            else {
                if (this.configuration.displayOnePointAsCrosshairs &&
                    annotation.data.contour.polyline.length === 1) {
                    this.renderPointContourWithMarker(enabledElement, svgDrawingHelper, annotation);
                }
                else {
                    this.renderContour(enabledElement, svgDrawingHelper, annotation);
                }
            }
            renderStatus = true;
        }
        if (!this.configuration.calculateStats) {
            return;
        }
        this._calculateStatsIfActive(annotation, targetId, viewport, renderingEngine, enabledElement);
        this._renderStats(annotation, viewport, enabledElement, svgDrawingHelper);
        return renderStatus;
    }
    _calculateStatsIfActive(annotation, targetId, viewport, renderingEngine, enabledElement) {
        const activeAnnotationUID = this.commonData?.annotation.annotationUID;
        if (annotation.annotationUID === activeAnnotationUID &&
            !this.commonData?.movingTextBox) {
            return;
        }
        if (!this.commonData?.movingTextBox) {
            const { data } = annotation;
            if (!data.cachedStats[targetId] ||
                data.cachedStats[targetId].areaUnit == null) {
                data.cachedStats[targetId] = {
                    Modality: null,
                    area: null,
                    max: null,
                    mean: null,
                    stdDev: null,
                    areaUnit: null,
                };
                this._calculateCachedStats(annotation, viewport, renderingEngine, enabledElement);
            }
            else if (annotation.invalidated) {
                this._throttledCalculateCachedStats(annotation, viewport, renderingEngine, enabledElement);
            }
        }
    }
}
function defaultGetTextLines(data, targetId) {
    const cachedVolumeStats = data.cachedStats[targetId];
    const { area, mean, stdDev, perimeter, max, isEmptyArea, areaUnit, modalityUnit, } = cachedVolumeStats || {};
    const textLines = [];
    if (area) {
        const areaLine = isEmptyArea
            ? `Area: Oblique not supported`
            : `Area: ${(0,_utilities__WEBPACK_IMPORTED_MODULE_3__.roundNumber)(area)} ${areaUnit}`;
        textLines.push(areaLine);
    }
    if (mean) {
        textLines.push(`Mean: ${(0,_utilities__WEBPACK_IMPORTED_MODULE_3__.roundNumber)(mean)} ${modalityUnit}`);
    }
    if (max) {
        textLines.push(`Max: ${(0,_utilities__WEBPACK_IMPORTED_MODULE_3__.roundNumber)(max)} ${modalityUnit}`);
    }
    if (stdDev) {
        textLines.push(`Std Dev: ${(0,_utilities__WEBPACK_IMPORTED_MODULE_3__.roundNumber)(stdDev)} ${modalityUnit}`);
    }
    if (perimeter) {
        textLines.push(`Perimeter: ${(0,_utilities__WEBPACK_IMPORTED_MODULE_3__.roundNumber)(perimeter)} ${modalityUnit}`);
    }
    return textLines;
}
PlanarFreehandROITool.toolName = 'PlanarFreehandROI';
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PlanarFreehandROITool);


/***/ }),

/***/ 31163:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(92136);
/* harmony import */ var _enums_SegmentationRepresentations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(83946);
/* harmony import */ var _stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(63421);
/* harmony import */ var _stateManagement_segmentation_config_segmentationVisibility__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(23308);
/* harmony import */ var _stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(30322);
/* harmony import */ var _store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(52610);
/* harmony import */ var _base__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(96214);
/* harmony import */ var _Surface__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(57313);
/* harmony import */ var _Contour__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2884);
/* harmony import */ var _Labelmap__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(94318);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(61738);
/* harmony import */ var _annotation_PlanarFreehandContourSegmentationTool__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(20070);













const planarContourToolName = _annotation_PlanarFreehandContourSegmentationTool__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .A.toolName;
class SegmentationDisplayTool extends _base__WEBPACK_IMPORTED_MODULE_6__/* .BaseTool */ .oS {
    constructor(toolProps = {}, defaultToolProps = {
        configuration: {},
    }) {
        super(toolProps, defaultToolProps);
        this.renderSegmentation = (toolGroupId) => {
            const toolGroup = (0,_store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_5__.getToolGroup)(toolGroupId);
            if (!toolGroup) {
                return;
            }
            const toolGroupSegmentationRepresentations = (0,_stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_4__.getSegmentationRepresentations)(toolGroupId);
            if (!toolGroupSegmentationRepresentations ||
                toolGroupSegmentationRepresentations.length === 0) {
                return;
            }
            const toolGroupViewports = toolGroup.viewportsInfo.map(({ renderingEngineId, viewportId }) => {
                const enabledElement = (0,_cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.getEnabledElementByIds)(viewportId, renderingEngineId);
                if (enabledElement) {
                    return enabledElement.viewport;
                }
            });
            const segmentationRenderList = toolGroupSegmentationRepresentations.map((representation) => {
                const config = this._getMergedRepresentationsConfig(toolGroupId);
                const viewportsRenderList = [];
                const renderers = {
                    [_enums_SegmentationRepresentations__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.Labelmap]: _Labelmap__WEBPACK_IMPORTED_MODULE_9__/* .labelmapDisplay */ .Zy,
                    [_enums_SegmentationRepresentations__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.Contour]: _Contour__WEBPACK_IMPORTED_MODULE_8__/* .contourDisplay */ .T,
                    [_enums_SegmentationRepresentations__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.Surface]: _Surface__WEBPACK_IMPORTED_MODULE_7__/* .surfaceDisplay */ .u,
                };
                if (representation.type === _enums_SegmentationRepresentations__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.Contour) {
                    this.addPlanarFreeHandToolIfAbsent(toolGroupId);
                }
                const display = renderers[representation.type];
                for (const viewport of toolGroupViewports) {
                    const renderedViewport = display.render(viewport, representation, config);
                    viewportsRenderList.push(renderedViewport);
                }
                return viewportsRenderList;
            });
            Promise.allSettled(segmentationRenderList).then(() => {
                toolGroupViewports.forEach((viewport) => {
                    viewport.render();
                });
            });
        };
    }
    onSetToolEnabled() {
        const toolGroupId = this.toolGroupId;
        const toolGroupSegmentationRepresentations = (0,_stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_4__.getSegmentationRepresentations)(toolGroupId);
        if (!toolGroupSegmentationRepresentations ||
            toolGroupSegmentationRepresentations.length === 0) {
            return;
        }
        toolGroupSegmentationRepresentations.forEach((segmentationRepresentation) => {
            (0,_stateManagement_segmentation_config_segmentationVisibility__WEBPACK_IMPORTED_MODULE_3__.setSegmentationVisibility)(toolGroupId, segmentationRepresentation.segmentationRepresentationUID, true);
        });
    }
    onSetToolDisabled() {
        const toolGroupId = this.toolGroupId;
        const toolGroupSegmentationRepresentations = (0,_stateManagement_segmentation_segmentationState__WEBPACK_IMPORTED_MODULE_4__.getSegmentationRepresentations)(toolGroupId);
        if (!toolGroupSegmentationRepresentations ||
            toolGroupSegmentationRepresentations.length === 0) {
            return;
        }
        toolGroupSegmentationRepresentations.forEach((segmentationRepresentation) => {
            (0,_stateManagement_segmentation_config_segmentationVisibility__WEBPACK_IMPORTED_MODULE_3__.setSegmentationVisibility)(toolGroupId, segmentationRepresentation.segmentationRepresentationUID, false);
        });
    }
    addPlanarFreeHandToolIfAbsent(toolGroupId) {
        if (!(planarContourToolName in _store__WEBPACK_IMPORTED_MODULE_10__/* .state */ .wk.tools)) {
            (0,_store__WEBPACK_IMPORTED_MODULE_10__/* .addTool */ .Gx)(_annotation_PlanarFreehandContourSegmentationTool__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .A);
        }
        const toolGroup = (0,_store_ToolGroupManager__WEBPACK_IMPORTED_MODULE_5__.getToolGroup)(toolGroupId);
        if (!toolGroup.hasTool(planarContourToolName)) {
            toolGroup.addTool(planarContourToolName);
            toolGroup.setToolPassive(planarContourToolName);
        }
    }
    _getMergedRepresentationsConfig(toolGroupId) {
        const toolGroupConfig = _stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_2__.config.getToolGroupSpecificConfig(toolGroupId);
        const globalConfig = _stateManagement_segmentation__WEBPACK_IMPORTED_MODULE_2__.config.getGlobalConfig();
        const mergedConfig = _cornerstonejs_core__WEBPACK_IMPORTED_MODULE_0__.utilities.deepMerge(globalConfig, toolGroupConfig);
        return mergedConfig;
    }
}
SegmentationDisplayTool.toolName = 'SegmentationDisplay';
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SegmentationDisplayTool);


/***/ }),

/***/ 51008:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/**
 * lodash (Custom Build) <https://lodash.com/>
 * Build: `lodash modularize exports="npm" -o ./`
 * Copyright jQuery Foundation and other contributors <https://jquery.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */

/** Used as the `TypeError` message for "Functions" methods. */
var FUNC_ERROR_TEXT = 'Expected a function';

/** Used to stand-in for `undefined` hash values. */
var HASH_UNDEFINED = '__lodash_hash_undefined__';

/** Used as references for various `Number` constants. */
var INFINITY = 1 / 0;

/** `Object#toString` result references. */
var funcTag = '[object Function]',
    genTag = '[object GeneratorFunction]',
    symbolTag = '[object Symbol]';

/** Used to match property names within property paths. */
var reIsDeepProp = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
    reIsPlainProp = /^\w*$/,
    reLeadingDot = /^\./,
    rePropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;

/**
 * Used to match `RegExp`
 * [syntax characters](http://ecma-international.org/ecma-262/7.0/#sec-patterns).
 */
var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;

/** Used to match backslashes in property paths. */
var reEscapeChar = /\\(\\)?/g;

/** Used to detect host constructors (Safari). */
var reIsHostCtor = /^\[object .+?Constructor\]$/;

/** Detect free variable `global` from Node.js. */
var freeGlobal = typeof __webpack_require__.g == 'object' && __webpack_require__.g && __webpack_require__.g.Object === Object && __webpack_require__.g;

/** Detect free variable `self`. */
var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

/** Used as a reference to the global object. */
var root = freeGlobal || freeSelf || Function('return this')();

/**
 * Gets the value at `key` of `object`.
 *
 * @private
 * @param {Object} [object] The object to query.
 * @param {string} key The key of the property to get.
 * @returns {*} Returns the property value.
 */
function getValue(object, key) {
  return object == null ? undefined : object[key];
}

/**
 * Checks if `value` is a host object in IE < 9.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a host object, else `false`.
 */
function isHostObject(value) {
  // Many host objects are `Object` objects that can coerce to strings
  // despite having improperly defined `toString` methods.
  var result = false;
  if (value != null && typeof value.toString != 'function') {
    try {
      result = !!(value + '');
    } catch (e) {}
  }
  return result;
}

/** Used for built-in method references. */
var arrayProto = Array.prototype,
    funcProto = Function.prototype,
    objectProto = Object.prototype;

/** Used to detect overreaching core-js shims. */
var coreJsData = root['__core-js_shared__'];

/** Used to detect methods masquerading as native. */
var maskSrcKey = (function() {
  var uid = /[^.]+$/.exec(coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO || '');
  return uid ? ('Symbol(src)_1.' + uid) : '';
}());

/** Used to resolve the decompiled source of functions. */
var funcToString = funcProto.toString;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var objectToString = objectProto.toString;

/** Used to detect if a method is native. */
var reIsNative = RegExp('^' +
  funcToString.call(hasOwnProperty).replace(reRegExpChar, '\\$&')
  .replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, '$1.*?') + '$'
);

/** Built-in value references. */
var Symbol = root.Symbol,
    splice = arrayProto.splice;

/* Built-in method references that are verified to be native. */
var Map = getNative(root, 'Map'),
    nativeCreate = getNative(Object, 'create');

/** Used to convert symbols to primitives and strings. */
var symbolProto = Symbol ? Symbol.prototype : undefined,
    symbolToString = symbolProto ? symbolProto.toString : undefined;

/**
 * Creates a hash object.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function Hash(entries) {
  var index = -1,
      length = entries ? entries.length : 0;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

/**
 * Removes all key-value entries from the hash.
 *
 * @private
 * @name clear
 * @memberOf Hash
 */
function hashClear() {
  this.__data__ = nativeCreate ? nativeCreate(null) : {};
}

/**
 * Removes `key` and its value from the hash.
 *
 * @private
 * @name delete
 * @memberOf Hash
 * @param {Object} hash The hash to modify.
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function hashDelete(key) {
  return this.has(key) && delete this.__data__[key];
}

/**
 * Gets the hash value for `key`.
 *
 * @private
 * @name get
 * @memberOf Hash
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function hashGet(key) {
  var data = this.__data__;
  if (nativeCreate) {
    var result = data[key];
    return result === HASH_UNDEFINED ? undefined : result;
  }
  return hasOwnProperty.call(data, key) ? data[key] : undefined;
}

/**
 * Checks if a hash value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf Hash
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function hashHas(key) {
  var data = this.__data__;
  return nativeCreate ? data[key] !== undefined : hasOwnProperty.call(data, key);
}

/**
 * Sets the hash `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf Hash
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the hash instance.
 */
function hashSet(key, value) {
  var data = this.__data__;
  data[key] = (nativeCreate && value === undefined) ? HASH_UNDEFINED : value;
  return this;
}

// Add methods to `Hash`.
Hash.prototype.clear = hashClear;
Hash.prototype['delete'] = hashDelete;
Hash.prototype.get = hashGet;
Hash.prototype.has = hashHas;
Hash.prototype.set = hashSet;

/**
 * Creates an list cache object.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function ListCache(entries) {
  var index = -1,
      length = entries ? entries.length : 0;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

/**
 * Removes all key-value entries from the list cache.
 *
 * @private
 * @name clear
 * @memberOf ListCache
 */
function listCacheClear() {
  this.__data__ = [];
}

/**
 * Removes `key` and its value from the list cache.
 *
 * @private
 * @name delete
 * @memberOf ListCache
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function listCacheDelete(key) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  if (index < 0) {
    return false;
  }
  var lastIndex = data.length - 1;
  if (index == lastIndex) {
    data.pop();
  } else {
    splice.call(data, index, 1);
  }
  return true;
}

/**
 * Gets the list cache value for `key`.
 *
 * @private
 * @name get
 * @memberOf ListCache
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function listCacheGet(key) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  return index < 0 ? undefined : data[index][1];
}

/**
 * Checks if a list cache value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf ListCache
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function listCacheHas(key) {
  return assocIndexOf(this.__data__, key) > -1;
}

/**
 * Sets the list cache `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf ListCache
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the list cache instance.
 */
function listCacheSet(key, value) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  if (index < 0) {
    data.push([key, value]);
  } else {
    data[index][1] = value;
  }
  return this;
}

// Add methods to `ListCache`.
ListCache.prototype.clear = listCacheClear;
ListCache.prototype['delete'] = listCacheDelete;
ListCache.prototype.get = listCacheGet;
ListCache.prototype.has = listCacheHas;
ListCache.prototype.set = listCacheSet;

/**
 * Creates a map cache object to store key-value pairs.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function MapCache(entries) {
  var index = -1,
      length = entries ? entries.length : 0;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

/**
 * Removes all key-value entries from the map.
 *
 * @private
 * @name clear
 * @memberOf MapCache
 */
function mapCacheClear() {
  this.__data__ = {
    'hash': new Hash,
    'map': new (Map || ListCache),
    'string': new Hash
  };
}

/**
 * Removes `key` and its value from the map.
 *
 * @private
 * @name delete
 * @memberOf MapCache
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function mapCacheDelete(key) {
  return getMapData(this, key)['delete'](key);
}

/**
 * Gets the map value for `key`.
 *
 * @private
 * @name get
 * @memberOf MapCache
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function mapCacheGet(key) {
  return getMapData(this, key).get(key);
}

/**
 * Checks if a map value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf MapCache
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function mapCacheHas(key) {
  return getMapData(this, key).has(key);
}

/**
 * Sets the map `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf MapCache
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the map cache instance.
 */
function mapCacheSet(key, value) {
  getMapData(this, key).set(key, value);
  return this;
}

// Add methods to `MapCache`.
MapCache.prototype.clear = mapCacheClear;
MapCache.prototype['delete'] = mapCacheDelete;
MapCache.prototype.get = mapCacheGet;
MapCache.prototype.has = mapCacheHas;
MapCache.prototype.set = mapCacheSet;

/**
 * Gets the index at which the `key` is found in `array` of key-value pairs.
 *
 * @private
 * @param {Array} array The array to inspect.
 * @param {*} key The key to search for.
 * @returns {number} Returns the index of the matched value, else `-1`.
 */
function assocIndexOf(array, key) {
  var length = array.length;
  while (length--) {
    if (eq(array[length][0], key)) {
      return length;
    }
  }
  return -1;
}

/**
 * The base implementation of `_.get` without support for default values.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {Array|string} path The path of the property to get.
 * @returns {*} Returns the resolved value.
 */
function baseGet(object, path) {
  path = isKey(path, object) ? [path] : castPath(path);

  var index = 0,
      length = path.length;

  while (object != null && index < length) {
    object = object[toKey(path[index++])];
  }
  return (index && index == length) ? object : undefined;
}

/**
 * The base implementation of `_.isNative` without bad shim checks.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a native function,
 *  else `false`.
 */
function baseIsNative(value) {
  if (!isObject(value) || isMasked(value)) {
    return false;
  }
  var pattern = (isFunction(value) || isHostObject(value)) ? reIsNative : reIsHostCtor;
  return pattern.test(toSource(value));
}

/**
 * The base implementation of `_.toString` which doesn't convert nullish
 * values to empty strings.
 *
 * @private
 * @param {*} value The value to process.
 * @returns {string} Returns the string.
 */
function baseToString(value) {
  // Exit early for strings to avoid a performance hit in some environments.
  if (typeof value == 'string') {
    return value;
  }
  if (isSymbol(value)) {
    return symbolToString ? symbolToString.call(value) : '';
  }
  var result = (value + '');
  return (result == '0' && (1 / value) == -INFINITY) ? '-0' : result;
}

/**
 * Casts `value` to a path array if it's not one.
 *
 * @private
 * @param {*} value The value to inspect.
 * @returns {Array} Returns the cast property path array.
 */
function castPath(value) {
  return isArray(value) ? value : stringToPath(value);
}

/**
 * Gets the data for `map`.
 *
 * @private
 * @param {Object} map The map to query.
 * @param {string} key The reference key.
 * @returns {*} Returns the map data.
 */
function getMapData(map, key) {
  var data = map.__data__;
  return isKeyable(key)
    ? data[typeof key == 'string' ? 'string' : 'hash']
    : data.map;
}

/**
 * Gets the native function at `key` of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {string} key The key of the method to get.
 * @returns {*} Returns the function if it's native, else `undefined`.
 */
function getNative(object, key) {
  var value = getValue(object, key);
  return baseIsNative(value) ? value : undefined;
}

/**
 * Checks if `value` is a property name and not a property path.
 *
 * @private
 * @param {*} value The value to check.
 * @param {Object} [object] The object to query keys on.
 * @returns {boolean} Returns `true` if `value` is a property name, else `false`.
 */
function isKey(value, object) {
  if (isArray(value)) {
    return false;
  }
  var type = typeof value;
  if (type == 'number' || type == 'symbol' || type == 'boolean' ||
      value == null || isSymbol(value)) {
    return true;
  }
  return reIsPlainProp.test(value) || !reIsDeepProp.test(value) ||
    (object != null && value in Object(object));
}

/**
 * Checks if `value` is suitable for use as unique object key.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is suitable, else `false`.
 */
function isKeyable(value) {
  var type = typeof value;
  return (type == 'string' || type == 'number' || type == 'symbol' || type == 'boolean')
    ? (value !== '__proto__')
    : (value === null);
}

/**
 * Checks if `func` has its source masked.
 *
 * @private
 * @param {Function} func The function to check.
 * @returns {boolean} Returns `true` if `func` is masked, else `false`.
 */
function isMasked(func) {
  return !!maskSrcKey && (maskSrcKey in func);
}

/**
 * Converts `string` to a property path array.
 *
 * @private
 * @param {string} string The string to convert.
 * @returns {Array} Returns the property path array.
 */
var stringToPath = memoize(function(string) {
  string = toString(string);

  var result = [];
  if (reLeadingDot.test(string)) {
    result.push('');
  }
  string.replace(rePropName, function(match, number, quote, string) {
    result.push(quote ? string.replace(reEscapeChar, '$1') : (number || match));
  });
  return result;
});

/**
 * Converts `value` to a string key if it's not a string or symbol.
 *
 * @private
 * @param {*} value The value to inspect.
 * @returns {string|symbol} Returns the key.
 */
function toKey(value) {
  if (typeof value == 'string' || isSymbol(value)) {
    return value;
  }
  var result = (value + '');
  return (result == '0' && (1 / value) == -INFINITY) ? '-0' : result;
}

/**
 * Converts `func` to its source code.
 *
 * @private
 * @param {Function} func The function to process.
 * @returns {string} Returns the source code.
 */
function toSource(func) {
  if (func != null) {
    try {
      return funcToString.call(func);
    } catch (e) {}
    try {
      return (func + '');
    } catch (e) {}
  }
  return '';
}

/**
 * Creates a function that memoizes the result of `func`. If `resolver` is
 * provided, it determines the cache key for storing the result based on the
 * arguments provided to the memoized function. By default, the first argument
 * provided to the memoized function is used as the map cache key. The `func`
 * is invoked with the `this` binding of the memoized function.
 *
 * **Note:** The cache is exposed as the `cache` property on the memoized
 * function. Its creation may be customized by replacing the `_.memoize.Cache`
 * constructor with one whose instances implement the
 * [`Map`](http://ecma-international.org/ecma-262/7.0/#sec-properties-of-the-map-prototype-object)
 * method interface of `delete`, `get`, `has`, and `set`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to have its output memoized.
 * @param {Function} [resolver] The function to resolve the cache key.
 * @returns {Function} Returns the new memoized function.
 * @example
 *
 * var object = { 'a': 1, 'b': 2 };
 * var other = { 'c': 3, 'd': 4 };
 *
 * var values = _.memoize(_.values);
 * values(object);
 * // => [1, 2]
 *
 * values(other);
 * // => [3, 4]
 *
 * object.a = 2;
 * values(object);
 * // => [1, 2]
 *
 * // Modify the result cache.
 * values.cache.set(object, ['a', 'b']);
 * values(object);
 * // => ['a', 'b']
 *
 * // Replace `_.memoize.Cache`.
 * _.memoize.Cache = WeakMap;
 */
function memoize(func, resolver) {
  if (typeof func != 'function' || (resolver && typeof resolver != 'function')) {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  var memoized = function() {
    var args = arguments,
        key = resolver ? resolver.apply(this, args) : args[0],
        cache = memoized.cache;

    if (cache.has(key)) {
      return cache.get(key);
    }
    var result = func.apply(this, args);
    memoized.cache = cache.set(key, result);
    return result;
  };
  memoized.cache = new (memoize.Cache || MapCache);
  return memoized;
}

// Assign cache to `_.memoize`.
memoize.Cache = MapCache;

/**
 * Performs a
 * [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
 * comparison between two values to determine if they are equivalent.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to compare.
 * @param {*} other The other value to compare.
 * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
 * @example
 *
 * var object = { 'a': 1 };
 * var other = { 'a': 1 };
 *
 * _.eq(object, object);
 * // => true
 *
 * _.eq(object, other);
 * // => false
 *
 * _.eq('a', 'a');
 * // => true
 *
 * _.eq('a', Object('a'));
 * // => false
 *
 * _.eq(NaN, NaN);
 * // => true
 */
function eq(value, other) {
  return value === other || (value !== value && other !== other);
}

/**
 * Checks if `value` is classified as an `Array` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an array, else `false`.
 * @example
 *
 * _.isArray([1, 2, 3]);
 * // => true
 *
 * _.isArray(document.body.children);
 * // => false
 *
 * _.isArray('abc');
 * // => false
 *
 * _.isArray(_.noop);
 * // => false
 */
var isArray = Array.isArray;

/**
 * Checks if `value` is classified as a `Function` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a function, else `false`.
 * @example
 *
 * _.isFunction(_);
 * // => true
 *
 * _.isFunction(/abc/);
 * // => false
 */
function isFunction(value) {
  // The use of `Object#toString` avoids issues with the `typeof` operator
  // in Safari 8-9 which returns 'object' for typed array and other constructors.
  var tag = isObject(value) ? objectToString.call(value) : '';
  return tag == funcTag || tag == genTag;
}

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */
function isObject(value) {
  var type = typeof value;
  return !!value && (type == 'object' || type == 'function');
}

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */
function isObjectLike(value) {
  return !!value && typeof value == 'object';
}

/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */
function isSymbol(value) {
  return typeof value == 'symbol' ||
    (isObjectLike(value) && objectToString.call(value) == symbolTag);
}

/**
 * Converts `value` to a string. An empty string is returned for `null`
 * and `undefined` values. The sign of `-0` is preserved.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to process.
 * @returns {string} Returns the string.
 * @example
 *
 * _.toString(null);
 * // => ''
 *
 * _.toString(-0);
 * // => '-0'
 *
 * _.toString([1, 2, 3]);
 * // => '1,2,3'
 */
function toString(value) {
  return value == null ? '' : baseToString(value);
}

/**
 * Gets the value at `path` of `object`. If the resolved value is
 * `undefined`, the `defaultValue` is returned in its place.
 *
 * @static
 * @memberOf _
 * @since 3.7.0
 * @category Object
 * @param {Object} object The object to query.
 * @param {Array|string} path The path of the property to get.
 * @param {*} [defaultValue] The value returned for `undefined` resolved values.
 * @returns {*} Returns the resolved value.
 * @example
 *
 * var object = { 'a': [{ 'b': { 'c': 3 } }] };
 *
 * _.get(object, 'a[0].b.c');
 * // => 3
 *
 * _.get(object, ['a', '0', 'b', 'c']);
 * // => 3
 *
 * _.get(object, 'a.b.c', 'default');
 * // => 'default'
 */
function get(object, path, defaultValue) {
  var result = object == null ? undefined : baseGet(object, path);
  return result === undefined ? defaultValue : result;
}

module.exports = get;


/***/ })

}]);